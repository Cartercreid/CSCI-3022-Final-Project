//
// Created by dev on 4/28/19.
//

#include "interface.h"
#include "../src/headers/decision.h"
#include "../src/headers/reporters.h"
#include "../src/headers/loaders.h"
#include "../src/headers/helpers.h"
#include <iostream>

using namespace std;

/*  COMMAND
 * ./interface "/home/dev/Projects/cs2270_final_project/tests/datasets/trainingset.csv" "/home/dev/Projects/cs2270_final_project/tests/datasets/testset.csv"
 * */

int main(int argc, char **argv) {
    //string test_set = argv[2];
    auto* args = new vector<string>();
    for (size_t i = 0; i < argc; i++) {
        args->push_back(argv[i]);
    }
    if (args->size() == 1) {
        cout << "No valid parameters." << endl;
        return 1;
    }
    if (args->at(1) == "--demo" || args->at(1) == "-d") {
        cout << TEST << DESCRIPTION1 << DESCRIPTION2 << DESCRIPTION3 << RESULTS;
        run_demo();
        return 0;
    } else if (args->at(1) == "--help" || args->at(1) == "-h") {
        cout << STARS << endl << RUN << STARS << NOTE1
        << NOTE2 << STARS << EXAMPLE1 << EXAMPLE2 << STARS;
        return 0;
    } else if (args->size() != 3) {
        cout << PATH_ERROR_MSG;
        return 1;
    }
    cout << STARS << CUSTOM1;
    cout << "* " << args->at(1) << endl << "* " << args->at(2);
    cout << endl << STARS << endl << endl << RESULTS;
    run_custom(args);
    return 0;
}

void run_demo() {
    Node* training_data = load_training_data("../tests/datasets/trainingset.csv");
    vector<Row*> data = load_test_data("../tests/datasets/testset.csv");
    Node* model = build_tree(training_data);
    vector<Prediction*> results = classify_test_data(model, data);
    report_predictions(results);
}

void run_custom(vector<string>* args) {
    Node* training_data = load_training_data(args->at(1));
    Node* model = build_tree(training_data);
    vector<Row*> test_data = load_test_data(args->at(2));
    vector<Prediction*> results = classify_test_data(model, test_data);
    report_predictions(results);
}