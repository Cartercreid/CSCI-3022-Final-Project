//
// Created by dev on 4/28/19.
//

#ifndef CS2270_FINAL_PROJECT_INTERFACE_H
#define CS2270_FINAL_PROJECT_INTERFACE_H

#include "../src/headers/decision.h"

const string PATH_ERROR_MSG = "TOO FEW ARGUMENTS\nEx:\n./interface <path/to/trainingset> <path/to/testingset>\n";
const string STARS = "* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *";
const string RUN = "* To run:\n*  $ ./interface <path/to/trainingset> <path/to/testingset>\n*  <OR>\n*  $ ./include --demo\n";
const string NOTE1 = "\n* Training data must be a CSV file with target labels\n* in left most column and header. ";
const string NOTE2 = "Test data must have\n* leading comma in place of left most column and no\n* header.\n";
const string EXAMPLE1 = "\n* Training Data Example\n* Label,Color,Size\n* Apple,Green,4\n";
const string EXAMPLE2 = "* Testing Data Example\n* Label,Color,Size\n* ,Orange,3\n";
const string TEST = "* * * * * * DEMO DESCRIPTION  * * * * *";
const string RESULTS = "* * * * * * * * RESULTS * * * * * * * *";
const string DESCRIPTION1 = "\n* The data below was not including in\n* model training. There should be 3\n* groups of labeled rows. ";
const string DESCRIPTION2 = "The first 5\n* should be `setosa`, next 5 should be\n* `versicolor`, and last 5 `virginica`.\n";
const string DESCRIPTION3 = "* The confidence should be 1 for all\n* samples.\n";
const string CUSTOM1 = "\n* Running your data from the follow paths:\n";

void run_demo();
void run_custom(vector<string>* args);

#endif //CS2270_FINAL_PROJECT_INTERFACE_H
