#pragma clang diagnostic push
#pragma ide diagnostic ignored "cert-err58-cpp"

//
// Created by dev on 4/19/19.
//

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <iostream>
#include <fstream>
#include "../src/headers/decision.h"
#include "../src/headers/classes.h"
#include "../src/headers/helpers.h"
#include "../src/headers/reporters.h"
#include "../src/headers/loaders.h"

using namespace std;


TEST(init_feature, feature_created) {
    Feature* feat = init_feature("Color", "Yellow");
    ASSERT_EQ(feat->label, "Color");
    ASSERT_EQ(feat->value, "Yellow");
    report_feature(feat);
}

TEST(init_row, row_created) {
    Feature* feat = init_feature("Color", "Yellow");
    Row* row = init_row("Apple");
    row->push(feat);
    ASSERT_EQ(row->feat_array.at(0)->value, "Yellow");
    report_row(row);
}

TEST(init_node, node_created) {
    Feature* feat = init_feature("Color", "Yellow");
    Row* row = init_row("Apple");
    Node* node = init_node();
    row->push(feat);
    node->push(row);
    ASSERT_EQ(node->row_array.at(0)->label, "Apple");
    report_node(node);
}

TEST(load_training_data, loads) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    ASSERT_EQ(node->row_array.at(0)->feat_array.at(0)->label, "Color");
    report_node(node);
}

TEST(unique_values, returns_vector) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    vector<Feature *> vector = unique_column_values(node);
    report_vector(vector);
}

TEST(unique_counts, returns_counts) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    auto counts = label_count(node);
    ASSERT_EQ(counts["Apple"], 3);
    report_counts(counts);
}

TEST(transform_numeric, returns_bool) {
    string s = "1abc";
    string d = "101.4";
    string i = "4";
    float answer = 0.0;
    bool is_num = convert2num(s, answer);
    ASSERT_FALSE(is_num);
    is_num = convert2num(d, answer);
    ASSERT_TRUE(is_num);
    is_num = convert2num(i, answer);
    ASSERT_TRUE(is_num);
}

TEST(Question, categorical) {
    Feature* question = init_feature("Color", "Yellow");
    Feature* sample1 = init_feature("Color", "Red");
    Feature* sample2 = init_feature("Color", "Yellow");

    report_feature(question);
    report_feature(sample1);
    report_feature(sample2);

    ASSERT_FALSE(question->match(sample1));
    ASSERT_TRUE(question->match(sample2));
}

TEST(Question, numerical) {
    Feature* question = init_feature("Size", "4");
    Feature* sample1 = init_feature("Size", "1");
    Feature* sample2 = init_feature("Size", "4");

    report_feature(question);
    report_feature(sample1);
    report_feature(sample2);

    ASSERT_FALSE(question->match(sample1));
    ASSERT_TRUE(question->match(sample2));
}

TEST(partition, categorical) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    Feature* question = init_feature("Color", "Red");
    cout << "\nQuestion (==)" << endl;
    report_feature(question);
    Partitions* parts = partition(node, question);
    report_parts(parts);
}

TEST(partition, numerical) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    Feature* question = init_feature("Size", "3");
    cout << "\nQuestion (>=)" << endl;
    report_feature(question);
    Partitions* parts = partition(node, question);
    report_parts(parts);
}

TEST(gini_impurity, returns_value) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    ASSERT_NEAR(gini_impurity(node), 0.69, 0.01);
    Node* half = load_training_data("../tests/datasets/half_mixed_fruit.csv");
    ASSERT_FLOAT_EQ(gini_impurity(half), 0.5);
    Node* full = load_training_data("../tests/datasets/full_mixed_fruit.csv");
    ASSERT_FLOAT_EQ(gini_impurity(full), 0.8);
    Node* pure = load_training_data("../tests/datasets/pure_fruit.csv");
    ASSERT_FLOAT_EQ(gini_impurity(pure), 0.0);
}

TEST(find_best_split, returns_split) {
    Node* set1 = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    Node* set2 = load_training_data("../tests/datasets/full_mixed_fruit.csv");
    Node* set3 = load_training_data("../tests/datasets/half_mixed_fruit.csv");
    Node* set4 = load_training_data("../tests/datasets/pure_fruit.csv");

    Feature* best_Q;

    best_Q = find_best_split(set1);
    ASSERT_EQ(best_Q->label, "Size");
    report_feature(best_Q);

    best_Q = find_best_split(set2);
    ASSERT_EQ(best_Q->label, "Color");
    report_feature(best_Q);

    best_Q = find_best_split(set3);
    ASSERT_EQ(best_Q->label, "Color");
    report_feature(best_Q);

    best_Q = find_best_split(set4);
    ASSERT_EQ(best_Q, nullptr);
}

TEST(build_tree, fruit) {
    Node* node = load_training_data("../tests/datasets/unbalanced_fruit.csv");
    build_tree(node);
    report_tree(node);
    ASSERT_TRUE(node != nullptr);
}

Node* training_data = load_training_data("../tests/datasets/trainingset.csv");
TEST(build_tree, irises) {
    build_tree(training_data);
    report_tree(training_data);
}

vector<Row*> data = load_test_data("../tests/datasets/testset.csv");
Node* model = build_tree(training_data);
TEST(classification, test_row) {
    unordered_map<string, int> result = classify_row(training_data,
            data.at(0));
    ASSERT_EQ(result.size(), 1);
    for (auto kvp : result) {
        ASSERT_EQ(kvp.first, "setosa");
    }
}

TEST(classification, test_dataset) {
    vector<Prediction*> results = classify_test_data(model, data);
    unordered_set<string> labels;
    for (size_t i = 0; i < 5; i++) {
        for (const string& l : results.at(i)->labels) {
            labels.insert(l);
        }
    }
    ASSERT_EQ(labels.size(), 1);
    ASSERT_EQ(labels.count("setosa"), 1);
    for (size_t i = 5; i < 10; i++) {
        for (const string& l : results.at(i)->labels) {
            labels.insert(l);
        }
    }
    ASSERT_EQ(labels.size(), 2);
    ASSERT_EQ(labels.count("versicolor"), 1);
    for (size_t i = 10; i < 15; i++) {
        for (const string& l : results.at(i)->labels) {
            labels.insert(l);
        }
    }
    ASSERT_EQ(labels.size(), 3);
    ASSERT_EQ(labels.count("virginica"), 1);
}

#pragma clang diagnostic pop