# DECISION TREE
#### (a command line tool)
## What are its goals:
Most generally, this project's goal is to classify
input data by label using a decision tree structure
and the CART algorithm.
## How it works, step by step:
    - load a csv into the program.
    - calculate the purity of the dataset by label.
    - check each feature of the data.
        - keep track of how well each feature divides
          the labels into more and more pure populations.
        - select the best feature.
    - use the best feature to divide data into subsets.
    - recursively repeat process of division.
        - find the point at which a subset can no longer
          be meaningfully divided.
    - apply the model to unseen data and get a
      classification.
## Complexity
I conducted a rough complexity analysis and have come
to the conclusion that the data structure and its
processes accomplish the set goals in no faster than
O(n) time where n is the number of rows of data in the
training input file. A more precise statement might be
to say that building a tree requires O(n rows of data)
* O(n of unique features in data).
## Instructions:
Change directories to the app folder.

`cd app/`

Build the program.

`cmake .`

`make`

Run help to get further commands and a description:

`./interface --help`

#### Additional commands described in `--help`

This command runs built-in data as a demo.

`./include --demo`

This is the interface command that runs your training and
test datasets.

`./interface <path/to/trainingset> <path/to/testingset>`

## Notes
Training data must be a CSV file with target labels
in left most column and a header at the top of the
file. Test data must have a comma positioned at the
left most position.

#### Example Training Data:
```
Label, Color, Size     // this is the header
Apple, Green, 4
Lemon, Yellow, 3
...
```

#### Example Test Data:
```
Label,Color,Size    // this is the header
,Green,5            // notice leading commas
,Red,2
,Yellow, 4
...
```
