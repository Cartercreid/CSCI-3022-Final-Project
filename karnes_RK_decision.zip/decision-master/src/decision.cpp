#include <utility>


//
// Created by dev on 4/19/19.
//

#include "headers/decision.h"
#include "headers/helpers.h"

using namespace std;


Node* build_tree(Node* node) {                                  // O(n)
    if (node->getGini() == 0.0) {                               // 8 * O(1) + O(n): rows at node
        // this creates pure nodes
        node->is_leaf = true;                                   // O(1)
        node->prediction = label_count(node);                   // 3 * O(1) + O(n): rows at node
        return node;                                            // O(1)
    }
    Feature* best = find_best_split(node);                      // O(n): rows at node
    if (best == nullptr) {                                      // O(1)
        return nullptr;
    }
    if (best->gain == 0.0) {                                    // O(1)
        node->is_leaf = true;                                   // O(1)
        node->prediction = label_count(node);                   // 3 * O(1) + O(n): rows at node
        return node;                                            // O(1)
    }
    node->question = best;                                      // O(1)
    Partitions* parts = partition(node, best);                  // 8 * O(1) + 2 * O(n)

    node->true_branch = build_tree(parts->true_node);           // O(n)
    node->false_branch = build_tree(parts->false_node);         // O(n)
    return node;                                                // O(1)
}


Feature* find_best_split(Node* node) {                          // [O(n): rows at node]
    float best_gain = 0.0;                                      // O(1)
    float current_uncertainty = node->getGini();                // 8 * O(1) + O(n): rows at node
    if (current_uncertainty == 0) {                             // O(1)
        return nullptr;
    }
    Feature* best_feature = nullptr;                            // O(1)
    Partitions* parts = nullptr;                                // O(1)

    vector<Feature*> vector = unique_column_values(node);       // 7 * O(1) + 2 * O(n): rows at node
    for (Feature* f : vector) {                                 // O(n): features at node
        parts = partition(node, f);                             // 8 * O(1) + 2 * O(n): rows/features at node
        if (!parts->trueSize() || !parts->falseSize()) {        // 2 * O(1)
            continue;
        }
        float gain = info_gain(parts, current_uncertainty);     // 9 * O(1): math
        if (gain > best_gain) {                                 // O(1)
            best_gain = gain;                                   // O(1)
            best_feature = f;                                   // O(1)
            best_feature->gain = best_gain;                     // O(1)
        }
    }
    return best_feature;                                        // O(1)
}


unordered_map<string, int> classify_row(Node* model, Row* row) {    // O(n): features in row
    if (model->is_leaf) {                                           // O(1)
        return model->prediction;                                   // O(1)
    }
    for (Feature* f : row->feat_array) {                            // O(n): features in row
        if (model->question->match(f)) {                            // 17 * O(1)
            return classify_row(model->true_branch, row);           // O(n)
        }
    }
    return classify_row(model->false_branch, row);                  // O(n)
}


vector<Prediction*> classify_test_data(Node* model, vector<Row*> data) {    // O(n)
    vector<Prediction*> classifications;                                    // O(1)
    for (Row* r : data) {                                                   // O(n): rows in vector
        unordered_map<string, int> row_class = classify_row(model, r);      // O(n)
        Prediction* pred = init_prediction();                               // O(3)
        for (const auto& kvp : row_class) {                                 // O(n): items in map
            pred->push(kvp.first);                                          // O(1)
        }
        classifications.push_back(pred);                                    // O(1)
    }
    return classifications;                                                 // O(1)
}
