//
// Created by Reagan K on 2019-05-05.
//

#include <iostream>
#include <fstream>
#include "headers/decision.h"
#include "headers/helpers.h"

Node* load_training_data(const string &path) {  // O(n): lines in file

    ifstream file(path);
    if (!file.is_open()) {
        cout << "File failed to open.\nCheck paths." << endl;
        exit(1);
    }

    Node* node = init_node();   // create new node
    string line;

    getline(file, line);
    vector<string> headers = get_row_values(line);  // extract headers
    vector<string> values;                          // value holder

    while (getline(file, line)) {

        // add parsed values to vector
        values = get_row_values(line);
        // use first item in vector, label, to init a new Row
        Row* row = init_row(values.at(0));

        for (size_t i = 1; i < values.size(); i++) {
            Feature* feat = init_feature(headers.at(i), values.at(i));
            row->push(feat);
        }

        node->push(row);    // add the Row to the Node
        values.clear();     // clear the value vector for next iteration
    }
    file.close();
    node->prediction = label_count(node);
    node->is_leaf = false;
    return node;
}

vector<Row*> load_test_data(const string &path) {   // O(n): lines in file

    ifstream file(path);
    if (!file.is_open()) {
        cout << "\n\nFile failed to open." << endl;
        exit(1);
    }

    vector<Row*> rows;
    string line;

    getline(file, line);
    vector<string> headers = get_row_values(line);  // extract headers
    vector<string> values;                          // values holder

    while (getline(file, line)) {
        // add parsed values to vector
        values = get_row_values(line);
        // use first item in vector, label, to init a new Row
        Row* row = init_row(values.at(0));  // note that index 0 here is "".

        for (size_t i = 1; i < values.size(); i++) {
            // for each value after the label we create a new Feature from
            // both headers and values and add to the Row
            Feature* feat = init_feature(headers.at(i), values.at(i));
            row->push(feat);
        }

        rows.push_back(row);
        values.clear();
    }
    file.close();
    return rows;
}