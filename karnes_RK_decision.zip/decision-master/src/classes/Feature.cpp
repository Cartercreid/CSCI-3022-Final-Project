//
// Created by Reagan K on 2019-05-05.
//

#include "../headers/decision.h"
#include "../headers/helpers.h"

Feature* init_feature(const string &label, const string &value) {   // 5 * O(1)

    Feature* feat = new Feature();
    feat->label = label;
    feat->value = value;
    feat->gain = 0;

    return feat;
}

bool Feature::match(Feature* sample) {                              // 17 * O(1)
    float sample_val = 0;                                           // O(1)
    float question_val = 0;                                         // O(1)
    if (sample->label == this->label) {                             // O(1)
        if (convert2num(sample->value, sample_val)) {               // 6 * O(1)
            convert2num(this->value, question_val);                 // 6 * O(1)
            return sample_val >= question_val;                      // O(1)
        } else {
            return sample->value == this->value;
        }
    }
    return false;                                                   // O(1)
}