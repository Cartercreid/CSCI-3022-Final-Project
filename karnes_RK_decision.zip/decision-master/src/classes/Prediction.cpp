//
// Created by Reagan K on 2019-05-05.
//

#include "../headers/decision.h"

Prediction* init_prediction() {                             // 3 * O(1)
    Prediction* pred = new Prediction();
    pred->confidence = 0;
    return pred;
}

void Prediction::push(const string& label) {                // 3 * O(1)
    this->labels.insert(label);
    this->confidence = 1.0 / (float) this->labels.size();
}