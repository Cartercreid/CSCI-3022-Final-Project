//
// Created by Reagan K on 2019-05-05.
//

#include "../headers/decision.h"
#include "../headers/helpers.h"

Node* init_node() {                 // 6 * O(1)

    Node* node = new Node;
    node->true_branch = nullptr;
    node->false_branch = nullptr;
    node->question = nullptr;
    node->is_leaf = false;
    return node;
}

int Node::size() {                  // O(1)
    return row_array.size();
}

void Node::push(Row* row) {         // O(1)
    row_array.push_back(row);
}

float Node::getGini() {             // O(1)
    return gini_impurity(this);
}