//
// Created by Reagan K on 2019-05-05.
//

#include "../headers/decision.h"
#include "../headers/helpers.h"

Partitions* init_partitions() {             // 3 * O(1)
    Partitions* parts = new Partitions();
    parts->true_node = init_node();
    parts->false_node = init_node();
    return parts;
}

int Partitions::trueSize() {                // O(1)
    return true_node->size();
}

int Partitions::falseSize() {               // O(1)
    return false_node->size();
}

float Partitions::trueGini() {              // O(1)
    return true_node->getGini();
}

float Partitions::falseGini(){              // O(1)
    return false_node->getGini();
}