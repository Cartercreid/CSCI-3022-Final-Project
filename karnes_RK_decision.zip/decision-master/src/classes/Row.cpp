//
// Created by Reagan K on 2019-05-05.
//

#include "../headers/decision.h"

Row* init_row(const string& label) {            // 4 * O(1)

    Row* row = new Row();

    if (label.empty()) {   // label handling
        row->label = "";
    } else {
        row->label = label;
    }

    return row;
}

int Row::size() {                               // O(1)
    return feat_array.size();
}

void Row::push(Feature *feature) {              // O(1)
    feat_array.push_back(feature);
}