//
// Created by Reagan K on 2019-05-05.
//

#include <sstream>
#include <cmath>
#include "headers/decision.h"
#include "headers/helpers.h"

const char delimiter = ',';

vector<string> get_row_values(string line) {                            // [9 * O(1)]
    line = line + delimiter;                                            // 2 * O(1)
    vector<string> value_vector;                                        // O(1)
    string value;                                                       // O(1)
    for (char i : line) {                                               // O(1)
        if (i != delimiter) {                                           // O(1)
            value += i;
            continue;
        }
        value_vector.push_back(value);                                  // O(1)
        value = "";                                                     // O(1)
    }
    return value_vector;                                                // O(1)
}


unordered_map<string, int> label_count(Node *node) {                    // [3 * O(1) + O(n)]
    unordered_map<string, int> counts;                                  // O(1)
    for (Row* r : node->row_array) {                                    // O(n): data rows
        counts[r->label] += 1;                                          // O(1)
    }
    return counts;                                                      // O(1)
}


Partitions* partition(Node* node, Feature* question) {                  // [7 * O(1) + 2 * O(n)]
    if (!question) {                                                // O(1)
        return nullptr;
    }
    Partitions* parts = init_partitions();                              // 3 * O(1)
    for (Row* r : node->row_array) {                                    // O(n): data rows
        for (Feature* f : r->feat_array) {                              // O(n): features
            // only values of like labels should be matched
            if (question->label == f->label) {                          // O(1)
                if (question->match(f)) {                               // O(1)
                    parts->true_node->push(r);
                } else {
                    parts->false_node->push(r);
                }
            }
        }
    }
    return parts;                                                       // O(1)
}


float gini_impurity(Node* node) {                                       // [7 * O(1) + O(n)]
    float impurity = 1.0;                                               // O(1)
    unordered_map<string, int> counts = label_count(node);              // 2 * O(1) + O(n): data rows
    for (pair<string, int> kvp : counts) {                              // O(n): counts
        impurity -= pow((float) kvp.second / (float) node->size(), 2);  // 3 * O(1)
    }
    return impurity;                                                    // O(1)
}


vector<Feature*> unique_column_values(Node *node) {                     // [6 * O(1) + 2 * O(n)]
    unordered_set<string> set;                                          // O(1)
    vector<Feature*> vector;                                            // O(1)
    for (Row* r : node->row_array) {                                    // O(n): data rows
        for (Feature* f : r->feat_array) {                              // O(n): features
            if (!set.count(f->value)) {                                 // O(1)
                set.insert(f->value);                                   // O(1)
                vector.push_back(f);                                    // O(1)
            }
        }
    }
    return vector;                                                      // O(1)
}


bool convert2num(const string& value, float& container) {               // [6 * O(1)]
    for (char c : value) {                                              // O(1)
        if (!isdigit(c) && c != '.') {                                  // 2 * O(1)
            return false;
        }
    }
    stringstream candidate(value);                                      // O(1)
    candidate >> container;                                             // O(1)
    return true;                                                        // O(1)
}


float info_gain(Partitions* parts, float current_uncertainty) {         // [8 * O(1)]
    float p = (float) parts->trueSize()                                 // 3 * O(1)
            / ( (float) parts->trueSize()
            + (float) parts->falseSize());
    return current_uncertainty - p                                      // 5 * O(1)
    * parts->trueGini() - (1 - p)
    * parts->falseGini();
}