//
// Created by Reagan K on 2019-05-06.
//

#ifndef DECISION_REPORTERS_H
#define DECISION_REPORTERS_H

#include "classes.h"

void report_feature(Feature* feature, string space="");
void report_row(Row* row, string space="");
void report_node(Node* node, string space="");
void report_tree(Node* tree, string space="", int level=0, string branch="");
void report_question(Feature* feature, string space);
void report_vector(vector<Feature*>& headers);
void report_counts(unordered_map<string, int> dict);
void report_parts(Partitions* parts);
void report_predictions(vector<Prediction*>& preds);

#endif //DECISION_REPORTERS_H
