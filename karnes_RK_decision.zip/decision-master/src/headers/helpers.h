//
// Created by Reagan K on 2019-05-06.
//

#ifndef DECISION_HELPERS_H
#define DECISION_HELPERS_H

#include "classes.h"

/* A helper function for the data loading
 * functions. Takes a line of text from the
 * `getline` STL method, splits it on commas,
 * and adds the resulting labels and values
 * to a vector.*/
vector<string> get_row_values(string line);

/* Takes a Node and iterates over its data
 * Rows to tally the number of unique values
 * present. Operates in O(n) time since every
 * row of data must be checked.*/
vector<Feature*> unique_column_values(Node *node);

/* Takes a Node and adds each unique Row label
 * to an unordered map, which is then returned.*/
unordered_map<string, int> label_count(Node *node);

/* Takes a value and a reference to a float, and
 * determines if the value is numeric or
 * categorical.*/
bool convert2num(const string& value, float& container);

/* Calculates the information gain from a partition
 * by comparing the respective Gini impurities of the
 * partition truth components.*/
float info_gain(Partitions* parts, float gini);

/* Takes a Node and counts unique labels. Then based
 * on the likelihood of drawing a random label and a
 * random object, determines the probability of
 * correctly labelling the randomly drawn object.*/
float gini_impurity(Node* node);

/* `partition` takes a Node and a Feature as a
 * question and returns a Partition object
 * containing two Nodes loaded with data rows
 * based on the truthfulness of the question
 * Feature as a divisor of the loaded data.
 * This also calculates the Gini impurity of
 * the resulting Nodes.*/
Partitions* partition(Node* node, Feature* question);

#endif //DECISION_HELPERS_H
