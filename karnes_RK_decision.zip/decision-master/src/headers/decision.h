//
// Created by dev on 4/19/19.
//

#ifndef CS2270_FINAL_PROJECT_DECISION_H
#define CS2270_FINAL_PROJECT_DECISION_H

#include "classes.h"

using namespace std;

/* The second most import function in the
 * decision tree implementation. A recursive
 * function that takes a Node, builds the tree
 * and returns same node, now as the root to the
 * decision tree. As a binary recursive tree this
 * operates in approximately O(n log n) time due
 * to the presence of the `find_best_split`
 * function calls.*/
Node* build_tree(Node* node);

/* The most important function in the decision
 * tree implementation. Takes a data Node and
 * partitions every unique column value, i.e.
 * Feature, in the entire data set. Returns
 * the Feature providing the max information
 * gain. Operates in O(n) time due to the
 * `unique_column_values` function being used.*/
Feature* find_best_split(Node* node);

/* Takes the trained model of a decision tree and
 * a single Row of test data and follows the model
 * down its branches until a leaf node is reached.
 * The leaf node provides the classification data
 * for the Row.*/
unordered_map<string, int> classify_row(Node* model, Row* row);

/* For each Row of test data, the `classify_row`
 * is applied and its result is recorded to a
 * vector which is then returned.*/
vector<Prediction*> classify_test_data(Node* model, vector<Row*> data);


#endif //CS2270_FINAL_PROJECT_DECISION_H
