//
// Created by Reagan K on 2019-05-05.
//

#ifndef DECISION_CLASSES_H
#define DECISION_CLASSES_H

#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;


/* The basic unit of division of data for this
 * decision tree implementation. Contains attributes
 * for label, value, and gain. These are used at
 * different steps in the decision tree's life.
 * Also contains a boolean method to compare the
 * Feature with another to see if they match, which
 * allows a Feature to act as a question.*/
class Feature {
public:
    string label;
    string value;
    float gain;
    bool match(Feature* sample);
};


/* Data structure corresponding to a single row
 * of data from a loaded CSV file. Consists of a
 * label and a Feature array for attributes. Has
 * methods for determining the size of the Feature
 * array and for adding to the Feature array.*/
class Row {
public:
    string label;
    vector<Feature*> feat_array;
    int size();
    void push(Feature* feature);
};


/* The Node is the primary tree object for the
 * decision tree data structure. It has attributes
 * and methods used during the recursive splits
 * of the loaded data, not all of which are used
 * at any particular step in the process.*/
class Node {
public:
    vector<Row*> row_array;
    Feature* question;
    Node* true_branch;
    Node* false_branch;
    bool is_leaf;
    unordered_map<string, int> prediction;
    int size();
    void push(Row* row);
    float getGini();
};


/* The Prediction class provides a structure to
 * hold an unordered, unique set of labels and a
 * confidence level associated with the length of
 * the labels set. If there are more than one
 * label in the set then the confidence will be
 * less than one. This corresponds to a data set
 * that cannot be completely purified with the
 * available features.*/
class Prediction {
public:
    unordered_set<string> labels;
    float confidence;
    void push(const string& label);
};


/* The Partitions object provides a holder for
 * two newly initialized Nodes that are then
 * available to have Rows pushed into them based
 * on the truthfulness of a Feature split.*/
class Partitions {
public:
    Node* true_node;
    Node* false_node;
    int trueSize();
    int falseSize();
    float trueGini();
    float falseGini();
};

/* `init_feat` initializes a Feature object and
 * sets all its attributes to their default
 * values.*/
Feature* init_feature(const string &label, const string &value);

/* `init_row` initializes a Row object and sets
 * all its attributes to their default values.*/
Row* init_row(const string& label);

/* `init_node` initializes a Node object and sets
 * all its attributes to their default values.*/
Node* init_node();

/* `init_prediction` initializes a Prediction
 * object and sets all its attributes to their
 * default values.*/
Prediction* init_prediction();

/* `init_partitions` initializes a Partition
 * object and sets all its attributes to their
 * default values.*/
Partitions* init_partitions();

#endif //DECISION_CLASSES_H
