//
// Created by Reagan K on 2019-05-06.
//

#ifndef DECISION_LOADERS_H
#define DECISION_LOADERS_H

#include "classes.h"

/* `load_training_data` takes a string path
 * to a CSV file and returns a Node object
 * loaded with the data from that file. This
 * is the data used to train the decision
 * tree.*/
Node* load_training_data(const string& path);

/* `load_test_data` takes a string path to a CSV
 * file and returns a vector of Rows containing
 * data from that file. This is the unlabelled
 * data used to test the decision tree.*/
vector<Row*> load_test_data(const string &path);

#endif //DECISION_LOADERS_H
