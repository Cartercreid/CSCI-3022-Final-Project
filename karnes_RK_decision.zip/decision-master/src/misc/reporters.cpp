//
// Created by dev on 4/21/19.
//

#include <iostream>
#include <iomanip>
#include "../headers/decision.h"
#include "../headers/reporters.h"
#include "../headers/helpers.h"

void report_feature(Feature* feature, string space) {
    if (feature == nullptr) {
        cout << "\nnull\n" << endl;
        return;
    }
    cout << endl;
    cout << space << "- Label: " << feature->label << endl;
    cout << space << "- Value: " << feature->value << endl;
}

void report_question(Feature* question, string space) {
    if (question == nullptr) {
        cout << space << "PURE DECISION" << endl;
        return;
    }
    cout << space << "Does " << question->label << " separate the data?";
}

void report_row(Row* row, string space) {
    if (row == nullptr) {
        cout << "\nnull\n" << endl;
        return;
    }
    cout << endl;
    cout << space << "{" << endl;
    cout << space << "Row: " << row->label;
    for (Feature* f : row->feat_array) {
        report_feature(f, space);
    }
    cout << space << "}" << endl;
}

void report_node(Node* node, string space) {
    if (node == nullptr) {
        cout << "\nnull\n" << endl;
        return;
    }
    for (Row* r : node->row_array) {
        report_row(r, space + '\t');
    }
}

void report_vector(vector<Feature*>& headers) {
    if (headers.size() == 0) {
        cout << "\nempty\n" << endl;
        return;
    }
    for (auto f : headers) {
        report_feature(f);
    }
}

void report_counts(unordered_map<string, int> dict) {
    cout << "\n=Counts=\n";
    for (auto kvp : dict) {
        cout << kvp.first << " : " << kvp.second << endl;
    }
}

void report_parts(Partitions* parts) {
    cout << "\nTRUE FEATURES\n";
    report_node(parts->true_node);
    cout << "FALSE FEATURES\n";
    report_node(parts->false_node);
}

void report_predictions(vector<Prediction*>& preds) {
    int i = 1;
    cout << endl;
    for (auto p : preds) {
        cout << "[" << i << "]\t";
        for (const auto& l : p->labels) {
            cout << setw(15) << left << l;
        }
        cout << "Confidence (" << p->confidence << ")" << endl;
        i++;
    }
}

void report_tree(Node* node, string space, int level, string branch) {
    if (!node) {    // null?
        return;
    }
    if (!level) {   // 0.0?
        cout << endl << space << "[ORIGINAL DATA]" << endl;
    } else {        // > 0.0
        cout << endl << space << branch << " LEVEL [" << level << "]" << endl;
        report_question(node->question, space);
    }
    report_node(node, space);
    if (node->true_branch != nullptr) {
        report_tree(node->true_branch, space + "\t", level + 1, "TRUE BRANCH FROM ABOVE,");
    }
    if (node->false_branch != nullptr) {
        report_tree(node->false_branch, space + "\t", level + 1, "FALSE BRANCH FROM ABOVE,");
    }
}