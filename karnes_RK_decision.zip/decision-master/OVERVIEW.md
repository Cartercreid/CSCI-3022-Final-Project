# DECISION TREE (DT)

###### by Reagan Karnes for CS2270 @ CU Boulder

### Rationale

My rational going forward was to find a data structure that I could use to help solve a **classification problem**. This idea came to me from the Huffman codec assignment where I build a tree to encode an input for the purposes of compression. I saw an analogy between the Huffman codec and the decision tree; in fact, you could argue that a Huffman codec is a type of decision tree, where the decision being made is the final encoding reached as the tree is traversed to the node containing the character. However, a key difference is that a Huffman codec invariant results in a unique output, whereas a Decision Tree is somewhat probabilistic depending on the separability of the input dataset. Thinking along these lines, I decided that I will try build a more generic decision tree for my data structure project.

### Problem

While the concept of a decision tree is pretty generic, I will guide the development of my implementation with a specific use case involving a dataset of 101 animals with 16 attributes (features), data here https://www.kaggle.com/uciml/zoo-animal-classification. Can I train a Decision tree on this dataset to correctly, or with reasonable probability of success, classify and label an unlabeled input?

### Overview

The purpose of my project as stated before is to come to a label classification decision based on a tree traversal. (1) Data is input to the root node of the tree with all the features common to each data point loaded as attributes. (2) Then an algorithm deduces from that data the most optimal feature to split on. This is an inherently greedy approach. (3) Once the data is split into left and right child nodes, the processes *repeats* recursively until the result consists either of a pure feature, or no improvement in information gain can be achieved through further splits.

### Input

The input will involved the full dataset, initializing a single node as root and loading it with that entire dataset. The dataset will be a list of rows with columns for features common to all datapoints. I will simplify by removing any rows with null values and do other such needed cleaning operations to make it suitable for my implementation.



### Split

##### Algorithm

The algorithm I am choosing for this implementation is *Classification And Regression Trees*, or CART for short. This algorithm will decide which question to ask (feature to split on) and at what stage (decision point) to ask.

##### Question

The root node, loaded with the full data, will ask a question about one of the features of that data. Based on the response to that question, i.e. positive or negative, we will split the dataset into two new subsets and add them as inputs to two newly initialized child nodes. Note that we will discard any questions which fail to produce a split.

##### Recursion

This question/split process will repeat for each of the child nodes based on the remaining available features present in the data subsets of the respective child nodes. The *ideal end goal is to unmix the data based on present features into leaf nodes with only a single label. The recursion will stop on two conditions.

A leaf node will have been reached if:

- The latest subset consists of only a single feature, i.e. a pure subset with one label associated with a single feature.
- *The subset can no longer be meaningfully split, i.e. multiple labels with identical remaining features.

### Algorithm

*How do I find the most effective question to ask at each decision point?*

The CART algorithm provides a way to quantify how much a question helps to filter the working dataset by its labels given the available features. I will use a metric called *Gini Impurity* to quantify the mixed-ness of the data subset at any given node, and using that combined with the concept of *Information Gain* I will quantify how effectively a question will filter the node's data on hand.

The algorithm will ask a yes/no question for each value of each feature present in the dataset, and look at the change in Gini impurity as a result of each potential split. The algorithm will choose the question, i.e. specific value of one of the available features, that provides the greatest information gain at that node. Again, this is a text book greedy algorithm with a divide and conquer motif and may very well miss the global optimum for the entire dataset.

##### Higher Algorithmic Resolution

As an important aside, we are reminded that each node takes a list of rows for its working dataset on input. The algortithm must then iterate (read **loop**) over every value of every feature that appears in those rows of data. Each of these unique *feature-values*, i.e. questions, becomes a candidate for splitting the data.

Each question and the dataset are passed into a function which divides the data into *true* and *false* subsets and calculates the new Gini impurity of the results. The question whose difference in Gini purity from the original will be chosen as the splitting question at the node.

##### Gini Impurity

This metric consists of a floating point number between the values of 0 and 1. This reflects the probability of randomly drawing an object from the population and having it match a randomly selected label from the population. A pure population has only one type of object and one label such that there is no uncertainty that the object and label will be correct, therefore the Gini impurity will be 0. A population with a Gini impurity of 1 would be such that the available label(s) match none of the objects present.

##### Information Gain

We first calculate the Gini impurity of the starting dataset at the root, i.e. the uncertainty of randomly choosing any one data point and any one label and having them be correct. Then for each question we can ask, we calculate the uncertainties of the resulting splits. Next we want to take *weighted average* of the uncertainties of those splits (because we would rather have a large subset with low uncertainty, rather than a small subset with high uncertainty). Next we find the difference between this and the starting uncertainty to calculate our information gain. For each node, the question producing the highest information gain will be chosen as the question for that node.

##### Decision Nodes

The leaf nodes are also called decision nodes, and they are unique in that they have two unique attributes, label and confidence. These attributes will be returned if an input traverses its way down the tree to the decision node. This provides both a prediction with confidence that a datapoint filtered by the tree has one label with 100% confidence, if a pure split was achieved, or that a datapoint has one of potentially many labels with a smaller confidence equal to the number of labels still present dividing 100. *Note, that this might be where the greedy nature of this algorithm can be incorrect as this is effectively a local minima in the degree of purity achievable accross the entire original dataset.*

### Weaknesses

Decision trees are considered unstable in that small data changes can result in vastly different optimal tree structures. There predictive values are often weak for which there are many other methods that perform better with similar data. Also, the information gain attribute of DT's tends to be biased towards categorical variables with a greater number of levels. And calculations can become overly complex when dealing with linked outcomes. They are also vulnerable to something called combinatoric explosion if the features are very great, or if more than a binary decision is required at any particular node.

### Strengths

DT's are easy to interpret and explain even to the least technical minds. They are great for deciding worst and best cases as well as making generalized predictions on expected outcomes. Can become very powerful when combined with other techniques, and are, as you will see, the building blocks for more advanced and powerful predictive structures. They are very good for taking a crack at high dimensionality data.

### Alternatives to Decision Trees

DT's, as I've outlined, have numerous faults. But there are steps that can be taken to improve their performance while strengthening their benefits and even completely eliminate some of those faults.

One structure that takes decision trees as its basic building block is the Random Forest (RF). These structures work as a collection of decision trees each with different algorithms/classifiers. Support for this is described by the concept that a *"group of weak learners come together to form a strong learner."* This makes a random forest a much more accurate model for decision making, even though they are not nearly as easy to interpret.

RF's often take advantage of a couple of concepts. One is the idea of bagging. This involves reducing variance in predictions by subsampling the original data to create many subset training datasets; this is similar to the concept of bootstrapping that is used elsewhere in statistical learning. Boosting is another concept that relies on the last classification to adjust the weight of the next observation, almost like a form of back-propagation, i.e. an incorrect classification will result in a greater weight assigned to that observation.

### Justification

Now, these alternative concepts and their related bonuses are more to do with the end use cases of the concepts surrounding decision trees themselves. And so, as a basic project in data structures, I have decided to go with the basic decision tree as it is a precursor to more advanced structures with nifty tricks of their own. Had I been aiming for a Support Vector Machine I'd be justified in tackling a simple KNN first!

That said, as complex as this structure is, it will certainly be much easier to implement than the downstream structures mentioned. And while I could achieve more accurate results using completely unrelated methods/structures for the given data and goals, my intention in tackling this data structure is to build my foundations of knowledge to be able to go on to understand and implement things like Random Forests, Kernel Methods, Multinomial Logistic Regression and naive Bayes classifiers.





### What does "done" look like?

Ideally, done will look like a program into which you can pass a single row of data, minus a label, and get a classification label and a confidence. I liken this to the output of the Huffman tree, where given a sequence of binary digits (or `^` and `.`), you get back a character.

Unit tests for this should have 100% class and method coverage with *well defined expectations* derived from cherry picked samples from the dataset. These cherry picked data samples will demonstrate that Gini impurity is being properly calculated and the consequences of those calculations are being properly executed. Tests will also ensure that pointer behavior is correct and null values properly handled. I would like to, as a bonus, add logic for exception handling, but will hold that for a cherry on top of a functional program.

### Conclusion

I believe I have covered the guidelines in the rubric for full credit on this writeup:

- 30% for being able to clearly and coherently state the problem that you're attempting to solve.
  - Classification of animals by 16 characteristics with a decision tree.
- 40% for being able to defend your choice of data structure (e.g. why did you not use X instead?).
  - While there are other methods which can solve this problem with greater accuracy with similar data, none of them serve as the foundation of the even more powerful methods of boosting and bagging decision trees, i.e. ensemble methods like boosting and bagging.
- 20% for describing your plan for implementing different parts of the code, How many functions do you think your data structure should have? How are you planning to implement each function? (recursive function?, looping over member variables? ... ).
  - The structure should consist of two kinds of nodes, internal nodes and decision nodes (leaf nodes) with shared and unique characteristics whose final assembled tree structure is defined by the CART algorithm.
- 10% for defining what 'done' looks like (one might propose writing unit-tests similar to class homework, then you should discuss how your tests are gonna look like).
  - Successfully, or at least making a good attempt, at solving the given problem. I intend for this to be a TDD implementation.